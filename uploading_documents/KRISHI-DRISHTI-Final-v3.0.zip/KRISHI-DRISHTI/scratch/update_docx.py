# -*- coding: utf-8 -*-
from docx import Document
from docx.shared import Pt

doc = Document('uploading_documents/KRISHI_DRISHTI_CBSE_STUDENT_PROJECT_REPORT_FILLED.docx')

# Find and replace Wi-Fi-related content in paragraphs
for para in doc.paragraphs:
    text = para.text
    # Update Section IV item 3 - Dual-Microcontroller Architecture
    if 'Dual-Microcontroller Architecture' in text or 'ESP32 DevKit V1 controller runs' in text:
        if '13 dBm' not in text:
            new_text = text.replace(
                'An ESP32 DevKit V1 controller runs an SSD1306 OLED (I2C GPIO 21/22) and reads a DHT11 sensor (GPIO 18) over a local wireless mesh.',
                'An ESP32 DevKit V1 controller runs an SSD1306 OLED (I2C GPIO 21/22) and reads a DHT11 sensor (GPIO 18). We linked the wand to the camera over Wi-Fi at 13 dBm TX power, using static IP 192.168.4.2 with DHCP fallback. The connection retries non-blocking every 5 seconds so the NEXT button keeps working even while the wand is still linking up.'
            )
            if new_text != text:
                para.text = new_text
                print(f'Updated paragraph: {para.text[:80]}...')

# Update tables if any
for table in doc.tables:
    for row in table.rows:
        for cell in row.cells:
            for para in cell.paragraphs:
                if '13 dBm' not in para.text and ('Wi-Fi' in para.text or '8.5' in para.text or '19.5' in para.text):
                    para.text = para.text.replace('8.5 dBm', '13 dBm').replace('19.5 dBm', '13 dBm')
                    print(f'Updated cell: {para.text[:80]}...')

doc.save('uploading_documents/KRISHI_DRISHTI_CBSE_STUDENT_PROJECT_REPORT_FILLED.docx')
print('DOCX updated successfully.')
