# -*- coding: utf-8 -*-
from docx import Document

doc = Document('uploading_documents/KRISHI_DRISHTI_CBSE_STUDENT_PROJECT_REPORT_FILLED.docx')

# Replace 13 dBm with 8.5 dBm in all paragraphs
count = 0
for para in doc.paragraphs:
    if '13 dBm' in para.text:
        para.text = para.text.replace('13 dBm', '8.5 dBm')
        count += 1

# Also check tables
for table in doc.tables:
    for row in table.rows:
        for cell in row.cells:
            for para in cell.paragraphs:
                if '13 dBm' in para.text:
                    para.text = para.text.replace('13 dBm', '8.5 dBm')
                    count += 1

doc.save('uploading_documents/KRISHI_DRISHTI_CBSE_STUDENT_PROJECT_REPORT_FILLED.docx')
print(f'Replaced 13 dBm with 8.5 dBm in {count} places.')
