import pymupdf, re

files = [
    'KRISHI_DRISHTI_CBSE_STUDENT_PROJECT_REPORT_FILLED.pdf',
    'KRISHI_DRISHTI_Field_Survey_Report.pdf',
    'KRISHI_DRISHTI_Project_Evidence_Dossier.pdf',
    'KRISHI_DRISHTI_Mentor_Recommendation_Filled.pdf',
    'mentor_projreport.pdf',
    'mentor_projreport_filled.pdf',
]

for fname in files:
    doc = pymupdf.open('uploading_documents/' + fname)
    text = ''
    for page in doc:
        text += page.get_text()
    wc = len(text.split())
    pages = doc.page_count
    images = sum(len(doc[i].get_images()) for i in range(doc.page_count))
    special = re.findall(r'[^\x00-\x7F]', text)
    qr_text = 'PROJECT ARCHIVE QR CODE' in text
    sign_end = 'Student Researchers: Gautam Kumar' in text[-300:]

    print(fname + ':')
    print('  Words: ' + str(wc) + ', Pages: ' + str(pages) + ', Images: ' + str(images))
    print('  QR text: ' + str(qr_text) + ', Special chars: ' + (str(set(special)) if special else 'none'))
    print('  Sign/stamp at end: ' + str(sign_end))
    print()
    doc.close()
