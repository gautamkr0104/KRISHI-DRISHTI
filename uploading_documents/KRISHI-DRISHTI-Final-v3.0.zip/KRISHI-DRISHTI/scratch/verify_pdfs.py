import pymupdf, re

files = {
    'KRISHI_DRISHTI_CBSE_STUDENT_PROJECT_REPORT_FILLED.pdf': False,
    'KRISHI_DRISHTI_Field_Survey_Report.pdf': False,
    'KRISHI_DRISHTI_Project_Evidence_Dossier.pdf': True,
    'KRISHI_DRISHTI_Mentor_Recommendation_Filled.pdf': False,
    'mentor_projreport.pdf': False,
    'mentor_projreport_filled.pdf': False,
}

all_ok = True
for fname, expect_qr in files.items():
    doc = pymupdf.open('uploading_documents/' + fname)
    text = ''
    for page in doc:
        text += page.get_text()
    wc = len(text.split())
    pages = doc.page_count
    special = re.findall(r'[^\x00-\x7F]', text)
    qr = 'PROJECT ARCHIVE QR CODE' in text

    if fname == 'KRISHI_DRISHTI_Project_Evidence_Dossier.pdf':
        images = sum(len(doc[i].get_images()) for i in range(doc.page_count))
        sign_at_end = 'Student Researchers: Gautam Kumar' in text[-300:]
        print('=== ' + fname + ' ===')
        print('  Words: ' + str(wc) + ', Pages: ' + str(pages) + ', QR: ' + str(qr) + ', Images: ' + str(images) + ', Special: ' + (str(set(special)) if special else 'none'))
        print('  Sign/stamp at end: ' + str(sign_at_end))
        if sign_at_end:
            print('  WARNING: Sign/stamp section found at end!')
            all_ok = False
    else:
        print(fname + ': ' + str(wc) + ' words, ' + str(pages) + ' pages, QR: ' + str(qr) + ', Special: ' + (str(set(special)) if special else 'none'))

    if special:
        print('  WARNING: Special chars found!')
        all_ok = False
    if qr != expect_qr:
        print('  WARNING: QR mismatch! Expected ' + str(expect_qr) + ', got ' + str(qr))
        all_ok = False
    doc.close()

print()
print('ALL OK' if all_ok else 'ISSUES FOUND')
