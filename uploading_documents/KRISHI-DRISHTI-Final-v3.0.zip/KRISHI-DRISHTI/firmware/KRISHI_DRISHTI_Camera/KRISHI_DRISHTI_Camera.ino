/*
  ==============================================================================
  KRISHI-DRISHTI (कृषि-दृष्टि) - Official Camera Unit Firmware v2.2
  Target Hardware: AI-Thinker ESP32-CAM (ESP-32S) + ESP32-CAM-MB Programmer Shield
  Optics: OV5640 / OV2640 Dual-Support Auto-Detection (UXGA 1600x1200)
  Storage: Onboard MicroSD in SD_MMC 1-Bit Mode (DMA Accelerated)
  Networking: SoftAP "KRISHI-DRISHTI" @ 192.168.4.1 (100% Offline Mesh)
  Author: Gautam Kumar / KRISHI-DRISHTI Project
  ==============================================================================
*/

#include "esp_camera.h"
#include "FS.h"
#include "SD_MMC.h"
#include <WiFi.h>
#include <WebServer.h>

// --------------------------------------------------
// CAMERA HARDWARE PIN DEFINITIONS (AI-Thinker)
// --------------------------------------------------
#define PWDN_GPIO_NUM     32
#define RESET_GPIO_NUM   -1
#define XCLK_GPIO_NUM      0
#define SIOD_GPIO_NUM     26
#define SIOC_GPIO_NUM     27

#define Y9_GPIO_NUM       35
#define Y8_GPIO_NUM       34
#define Y7_GPIO_NUM       39
#define Y6_GPIO_NUM       36
#define Y5_GPIO_NUM       21
#define Y4_GPIO_NUM       19
#define Y3_GPIO_NUM       18
#define Y2_GPIO_NUM        5

#define VSYNC_GPIO_NUM    25
#define HREF_GPIO_NUM     23
#define PCLK_GPIO_NUM     22

#define FLASH_LED_PIN      4  // High-power onboard illumination LED

// --------------------------------------------------
// WI-FI SOFTAP CREDENTIALS
// --------------------------------------------------
const char* AP_SSID = "KRISHI-DRISHTI";
const char* AP_PASSWORD = "12345678";

// --------------------------------------------------
// SERVER AND GLOBAL TELEMETRY STATE
// --------------------------------------------------
WebServer server(80);

bool cameraReady = false;
bool sdReady = false;
bool psramAvailable = false;
String sensorModel = "Unknown";

uint32_t scanCounter = 0;
float lastCanopyTemp = 0.0;
float lastCanopyHum = 0.0;
bool canopyTelemetryPresent = false;
unsigned long lastWandActivityMs = 0;
static bool isStreaming = false;

// AI Diagnosis Bridge State (Phone AI Daemon <-> Camera <-> Controller Wand)
bool diagnosisReady = false;
uint32_t diagScanId = 0;
String diagCrop = "Tomato";
String diagDisease = "Healthy";
float diagConfidence = 98.0;
String diagStatus = "HEALTHY";
String diagOrganic = "Maintain balanced irrigation & NPK";
String diagChemical = "No chemical intervention needed";

// --------------------------------------------------
// EMBEDDED EDGE AI SERVER DAEMON (SERVED AT /)
// --------------------------------------------------
const char AI_SERVER_HTML[] PROGMEM = R"rawliteral(<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>KRISHI-DRISHTI :: Edge AI Co-Processor</title>
  
  <!-- Bundled Offline TensorFlow.js & TFLite WASM Runtimes -->
  <script src="/vendor/tf.min.js"></script>
  <script src="/vendor/tf-tflite.min.js"></script>

  <style>
    :root {
      --bg-base: #070B0E;
      --bg-surface: #0E141B;
      --bg-surface-elevated: #141D26;
      --bg-surface-glass: rgba(16, 24, 34, 0.85);
      --border-subtle: rgba(255, 255, 255, 0.07);
      --border-focus: rgba(16, 185, 129, 0.4);
      
      --accent-emerald: #10B981;
      --accent-emerald-dim: rgba(16, 185, 129, 0.15);
      --accent-teal: #14B8A6;
      --accent-amber: #F59E0B;
      --accent-amber-dim: rgba(245, 158, 11, 0.15);
      --accent-rose: #F43F5E;
      --accent-rose-dim: rgba(244, 63, 94, 0.15);
      --accent-cyan: #06B6D4;
      
      --text-main: #F1F5F9;
      --text-muted: #94A3B8;
      --text-dim: #64748B;
      
      --font-sans: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      --font-mono: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
      --radius-sm: 8px;
      --radius-md: 14px;
      --radius-lg: 20px;
      --shadow-glass: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-tap-highlight-color: transparent;
    }

    body {
      background-color: var(--bg-base);
      background-image: 
        radial-gradient(at 0% 0%, rgba(16, 185, 129, 0.08) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(20, 184, 166, 0.06) 0px, transparent 50%);
      background-attachment: fixed;
      color: var(--text-main);
      font-family: var(--font-sans);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 14px;
    }

    .app-shell {
      width: 100%;
      max-width: 1180px;
      display: flex;
      flex-direction: column;
      gap: 14px;
    }

    /* TOP BRAND NAVIGATION BAR */
    .top-navbar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      background: var(--bg-surface-glass);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
      border: 1px solid var(--border-subtle);
      border-radius: var(--radius-md);
      padding: 12px 18px;
      box-shadow: var(--shadow-glass);
    }

    .brand-group {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .brand-icon {
      width: 38px;
      height: 38px;
      border-radius: 10px;
      background: linear-gradient(135deg, #10B981, #059669);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 20px;
      box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
    }

    .brand-meta {
      display: flex;
      flex-direction: column;
    }

    .brand-title-wrap {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .brand-name {
      font-size: 17px;
      font-weight: 700;
      letter-spacing: -0.02em;
      color: #FFFFFF;
    }

    .version-pill {
      font-size: 10px;
      font-weight: 600;
      text-transform: uppercase;
      padding: 2px 7px;
      border-radius: 6px;
      background: var(--accent-emerald-dim);
      color: var(--accent-emerald);
      border: 1px solid rgba(16, 185, 129, 0.3);
      font-family: var(--font-mono);
    }

    .brand-desc {
      font-size: 12px;
      color: var(--text-muted);
    }

    .status-pill {
      display: flex;
      align-items: center;
      gap: 7px;
      padding: 6px 14px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 600;
      letter-spacing: 0.02em;
      transition: all 0.3s ease;
      font-family: var(--font-mono);
    }

    .status-pill.pill-running {
      background: var(--accent-emerald-dim);
      color: var(--accent-emerald);
      border: 1px solid rgba(16, 185, 129, 0.4);
    }

    .status-pill.pill-stopped {
      background: rgba(148, 163, 184, 0.1);
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
    }

    .pulsing-dot {
      width: 7px;
      height: 7px;
      border-radius: 50%;
      background-color: currentColor;
      box-shadow: 0 0 8px currentColor;
      animation: pulse 1.8s infinite;
    }

    @keyframes pulse {
      0%, 100% { opacity: 1; transform: scale(1); }
      50% { opacity: 0.4; transform: scale(0.8); }
    }

    /* TELEMETRY METRICS 6-GRID */
    .metrics-bar {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
      gap: 10px;
    }

    @media (max-width: 640px) {
      .metrics-bar {
        grid-template-columns: repeat(2, 1fr);
        gap: 8px;
      }
      .metric-card {
        padding: 8px 10px;
      }
      .metric-header {
        font-size: 10px;
      }
      .metric-value {
        font-size: 13px;
      }
      .brand-desc {
        display: none;
      }
      .brand-name {
        font-size: 16px;
      }
      .hardware-card {
        flex-direction: column;
        align-items: stretch;
        gap: 8px;
      }
      .btn-hw-check {
        width: 100%;
        text-align: center;
      }
      .btn-secondary {
        padding: 9px 8px;
        font-size: 11px;
      }
    }

    .metric-card {
      background: var(--bg-surface-glass);
      backdrop-filter: blur(12px);
      border: 1px solid var(--border-subtle);
      border-radius: var(--radius-sm);
      padding: 10px 14px;
      display: flex;
      flex-direction: column;
      gap: 4px;
      transition: border-color 0.2s;
    }

    .metric-card:hover {
      border-color: var(--border-focus);
    }

    .metric-header {
      font-size: 11px;
      font-weight: 500;
      color: var(--text-dim);
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .metric-value {
      font-size: 14px;
      font-weight: 700;
      font-family: var(--font-mono);
      color: var(--text-main);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    /* MAIN 2-COLUMN WORKSPACE */
    .workspace-grid {
      display: grid;
      grid-template-columns: 1fr;
      gap: 14px;
    }

    @media (min-width: 900px) {
      .workspace-grid {
        grid-template-columns: 420px 1fr;
      }
    }

    /* CARD CONTAINER */
    .glass-panel {
      background: var(--bg-surface-glass);
      backdrop-filter: blur(16px);
      border: 1px solid var(--border-subtle);
      border-radius: var(--radius-md);
      padding: 16px;
      box-shadow: var(--shadow-glass);
      display: flex;
      flex-direction: column;
      gap: 14px;
    }

    .panel-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 1px solid var(--border-subtle);
      padding-bottom: 10px;
    }

    .panel-title {
      font-size: 13px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      color: var(--text-muted);
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .panel-badge {
      font-size: 10px;
      font-family: var(--font-mono);
      color: var(--text-dim);
      background: var(--bg-surface-elevated);
      padding: 2px 8px;
      border-radius: 4px;
    }

    /* VIEWPORT / LEAF FRAME */
    .viewfinder-wrap {
      width: 100%;
      aspect-ratio: 1 / 1;
      max-height: 380px;
      background: #040709;
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: var(--radius-md);
      position: relative;
      overflow: hidden;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto;
    }

    .viewfinder-grid-lines {
      position: absolute;
      inset: 0;
      background-image: 
        linear-gradient(rgba(255, 255, 255, 0.03) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255, 255, 255, 0.03) 1px, transparent 1px);
      background-size: 24px 24px;
      pointer-events: none;
    }

    .viewfinder-crosshair {
      position: absolute;
      width: 48px;
      height: 48px;
      border: 1px dashed rgba(16, 185, 129, 0.3);
      border-radius: 50%;
      pointer-events: none;
    }

    .viewfinder-corners {
      position: absolute;
      inset: 16px;
      pointer-events: none;
    }
    .viewfinder-corners::before {
      content: '';
      position: absolute;
      top: 0; left: 0; width: 14px; height: 14px;
      border-top: 2px solid var(--accent-emerald);
      border-left: 2px solid var(--accent-emerald);
    }
    .viewfinder-corners::after {
      content: '';
      position: absolute;
      bottom: 0; right: 0; width: 14px; height: 14px;
      border-bottom: 2px solid var(--accent-emerald);
      border-right: 2px solid var(--accent-emerald);
    }

    .leaf-preview-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: none;
      z-index: 2;
    }

    .leaf-placeholder {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 10px;
      color: var(--text-dim);
      font-size: 13px;
      z-index: 1;
    }

    .leaf-placeholder svg {
      width: 42px;
      height: 42px;
      stroke: currentColor;
      opacity: 0.6;
    }

    /* ACTION BUTTONS & SAMPLES */
    .action-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 10px;
    }

    .btn-main {
      grid-column: span 2;
      padding: 13px 18px;
      border-radius: var(--radius-sm);
      border: none;
      font-size: 14px;
      font-weight: 700;
      letter-spacing: 0.02em;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      background: linear-gradient(135deg, #10B981, #059669);
      color: #FFFFFF;
      box-shadow: 0 4px 14px rgba(16, 185, 129, 0.35);
      transition: all 0.2s ease;
    }

    .btn-main:active {
      transform: scale(0.98);
    }

    .btn-secondary {
      padding: 10px 14px;
      border-radius: var(--radius-sm);
      border: 1px solid var(--border-subtle);
      background: var(--bg-surface-elevated);
      color: var(--text-main);
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      transition: background 0.2s;
    }

    .btn-secondary:hover {
      background: rgba(255, 255, 255, 0.08);
    }

    .sample-pill-row {
      display: grid;
      grid-template-columns: 1fr 1fr 1fr;
      gap: 8px;
    }

    .btn-sample {
      padding: 8px 10px;
      border-radius: var(--radius-sm);
      font-size: 11px;
      font-weight: 600;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 4px;
      text-align: center;
      border: 1px solid var(--border-subtle);
      background: var(--bg-surface);
      color: var(--text-muted);
      transition: all 0.2s;
    }

    .btn-sample:hover {
      border-color: var(--border-focus);
      color: var(--text-main);
    }

    .btn-sample-blight {
      border-color: rgba(245, 158, 11, 0.3);
      color: #FCD34D;
    }

    .btn-sample-healthy {
      border-color: rgba(16, 185, 129, 0.3);
      color: #6EE7B7;
    }

    .btn-sample-upload {
      border-color: rgba(6, 182, 212, 0.3);
      color: #67E8F9;
    }

    /* RIGHT COLUMN: DIAGNOSTIC REPORT */
    .diagnosis-hero-box {
      background: linear-gradient(180deg, rgba(20, 29, 38, 0.9) 0%, rgba(14, 20, 27, 0.95) 100%);
      border: 1px solid var(--border-subtle);
      border-radius: var(--radius-md);
      padding: 16px;
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .diag-title-row {
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 12px;
    }

    .diag-primary {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: -0.01em;
      color: #FFFFFF;
      line-height: 1.2;
    }

    .diag-pathogen {
      font-size: 13px;
      font-style: italic;
      color: var(--text-muted);
    }

    .diag-confidence {
      font-size: 12px;
      font-family: var(--font-mono);
      color: var(--accent-emerald);
      background: var(--accent-emerald-dim);
      padding: 4px 10px;
      border-radius: 6px;
      display: inline-block;
      align-self: flex-start;
      border: 1px solid rgba(16, 185, 129, 0.2);
    }

    /* PRESCRIPTION BOX */
    .presc-card {
      background: var(--bg-surface);
      border: 1px solid var(--border-subtle);
      border-radius: var(--radius-sm);
      padding: 14px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .rx-badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: var(--accent-emerald);
    }

    .rx-section {
      display: flex;
      flex-direction: column;
      gap: 4px;
      border-left: 2px solid var(--accent-emerald);
      padding-left: 10px;
    }

    .rx-subhead {
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      color: var(--text-dim);
    }

    .rx-body {
      font-size: 13px;
      line-height: 1.5;
      color: var(--text-main);
    }

    .rx-section-chem {
      border-left-color: var(--accent-amber);
    }

    /* HARDWARE STATUS WIDGET */
    .hardware-card {
      border: 1px solid rgba(245, 158, 11, 0.25);
      background: rgba(245, 158, 11, 0.04);
      border-radius: var(--radius-sm);
      padding: 12px 14px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
    }

    .hw-info {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    .hw-title {
      font-size: 13px;
      font-weight: 600;
      color: var(--text-main);
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .hw-desc {
      font-size: 11px;
      color: var(--text-muted);
    }

    .btn-hw-check {
      background: var(--bg-surface-elevated);
      border: 1px solid var(--border-subtle);
      color: var(--text-main);
      padding: 7px 12px;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 600;
      cursor: pointer;
      white-space: nowrap;
      transition: all 0.2s;
    }

    .btn-hw-check:hover {
      background: rgba(255, 255, 255, 0.1);
    }

    /* ACTIVITY CONSOLE DRAWER */
    .activity-container {
      background: #05080A;
      border: 1px solid var(--border-subtle);
      border-radius: var(--radius-md);
      overflow: hidden;
      display: flex;
      flex-direction: column;
    }

    .activity-header {
      padding: 10px 14px;
      background: rgba(255, 255, 255, 0.02);
      border-bottom: 1px solid var(--border-subtle);
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 11px;
      font-weight: 600;
      color: var(--text-dim);
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .terminal-feed {
      height: 120px;
      overflow-y: auto;
      padding: 10px 14px;
      font-family: var(--font-mono);
      font-size: 11px;
      line-height: 1.6;
      display: flex;
      flex-direction: column;
      gap: 3px;
    }

    .log-line {
      display: flex;
      gap: 8px;
    }

    .log-t { color: var(--text-dim); }
    .log-tag-ok { color: var(--accent-emerald); font-weight: 700; }
    .log-tag-err { color: var(--accent-rose); font-weight: 700; }
    .log-tag-ai { color: var(--accent-cyan); font-weight: 700; }
    .log-tag-warn { color: var(--accent-amber); font-weight: 700; }
    .log-tag-info { color: var(--text-muted); font-weight: 700; }

    /* FOOTER */
    .app-footer {
      text-align: center;
      font-size: 11px;
      color: var(--text-dim);
      padding: 8px 0;
    }
  </style>
</head>
<body>

  <div class="app-shell">

    <!-- Brand Header -->
    <header class="top-navbar">
      <div class="brand-group">
        <div class="brand-icon">🌱</div>
        <div class="brand-meta">
          <div class="brand-title-wrap">
            <span class="brand-name">KRISHI-DRISHTI</span>
            <span class="version-pill">v2.2 EDGE</span>
          </div>
          <span class="brand-desc">Offline Field Neural Co-Processor &bull; MobileNetV3</span>
        </div>
      </div>
      <div id="statusPill" class="status-pill pill-stopped">
        <span class="pulsing-dot"></span>
        <span id="statusText">STANDBY</span>
      </div>
    </header>

    <!-- 6-Metric Telemetry Bar -->
    <section class="metrics-bar">
      <div class="metric-card">
        <span class="metric-header">Cam Gateway</span>
        <span class="metric-value" id="valCameraLink" style="color: var(--text-dim)">SEARCHING...</span>
      </div>
      <div class="metric-card">
        <span class="metric-header">MicroSD Storage</span>
        <span class="metric-value" id="valSdStatus" style="color: var(--accent-amber)">CHECKING...</span>
      </div>
      <div class="metric-card">
        <span class="metric-header">Sensor Wand</span>
        <span class="metric-value" id="valWandLink" style="color: var(--text-dim)">WAND OFF</span>
      </div>
      <div class="metric-card">
        <span class="metric-header">Neural Engine</span>
        <span class="metric-value" id="valEngine" style="color: var(--accent-amber)">LOADING...</span>
      </div>
      <div class="metric-card">
        <span class="metric-header">Inference</span>
        <span class="metric-value" id="valLatency">-- ms</span>
      </div>
      <div class="metric-card">
        <span class="metric-header">Field Syncs</span>
        <span class="metric-value" id="valScanCount">0</span>
      </div>
    </section>

    <!-- Main Workspace (2-Column on Desktop, Stack on Mobile) -->
    <div class="workspace-grid">

      <!-- LEFT COLUMN: Optical Viewfinder & Action Controls -->
      <div class="glass-panel">
        <div class="panel-header">
          <span class="panel-title">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>
            Optical Leaf Viewfinder
          </span>
          <span class="panel-badge" id="scanTimestamp">AWAITING SCAN</span>
        </div>

        <div class="viewfinder-wrap" id="leafThumbWrap">
          <div class="viewfinder-grid-lines"></div>
          <div class="viewfinder-crosshair"></div>
          <div class="viewfinder-corners"></div>
          <div class="leaf-placeholder" id="thumbPlaceholder">
            <svg viewBox="0 0 24 24" fill="none" stroke-width="1.5"><path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"/><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/></svg>
            <span>Waiting for Wand Shutter [SCAN]</span>
          </div>
          <img id="leafImg" class="leaf-preview-img" alt="Leaf Scan" />
        </div>

        <!-- Sample Palettes & Custom Upload -->
        <div class="sample-pill-row">
          <button class="btn-sample btn-sample-blight" onclick="testRealLeaf('/sample_leaves/late_blight_512.jpg', 'Real Tomato Late Blight')">
            🍂 Blight
          </button>
          <button class="btn-sample btn-sample-healthy" onclick="testRealLeaf('/sample_leaves/healthy_512.jpg', 'Real Tomato Healthy')">
            🌿 Healthy
          </button>
          <label class="btn-sample btn-sample-upload">
            📷 Upload
            <input type="file" id="leafFileInput" accept="image/*" style="display: none;" onchange="handleLeafUpload(event)">
          </label>
        </div>

        <!-- Server Toggle & Demo Buttons -->
        <div class="action-row">
          <button class="btn-main" id="btnToggle" onclick="toggleServer()">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="5 3 19 12 5 21 5 3"/></svg>
            START AI INFERENCE SERVER
          </button>
          <button class="btn-secondary" onclick="simulateFieldScan()">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8"/></svg>
            DEMO SCAN
          </button>
          <button class="btn-secondary" onclick="pollMeshNow()">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/></svg>
            AUDIT HW
          </button>
        </div>
      </div>

      <!-- RIGHT COLUMN: Edge AI Diagnosis & Agronomic Advisory -->
      <div class="glass-panel">
        <div class="panel-header">
          <span class="panel-title">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
            Edge AI Diagnosis & Telemetry
          </span>
          <span class="panel-badge">Dual-Domain Solanaceae Core</span>
        </div>

        <!-- Diagnosis Result Hero Card -->
        <div class="diagnosis-hero-box">
          <div class="diag-title-row">
            <div>
              <div class="diag-primary" id="diagPrimary">Waiting for Wand [SCAN]</div>
              <div class="diag-pathogen" id="diagPathogen">Mesh SoftAP: KRISHI-DRISHTI (192.168.4.1)</div>
            </div>
            <div class="diag-confidence" id="diagConfidence">Core: 2.01 MB TFLite</div>
          </div>
        </div>

        <!-- Clinical Agronomic Advisory -->
        <div class="presc-card" id="prescBox">
          <div class="rx-badge">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
            <span id="rxLabel">Agronomic Advisory & Treatment Protocol</span>
          </div>

          <div class="rx-section">
            <span class="rx-subhead">Biological & Cultural Control</span>
            <div class="rx-body" id="rxBio">Keep phone in pocket. When you press SCAN on the wand, results sync here and to the SSD1306 OLED automatically.</div>
          </div>

          <div class="rx-section rx-section-chem">
            <span class="rx-subhead">Chemical Intervention (ICAR / KVK Guidelines)</span>
            <div class="rx-body" id="rxChem" style="color: var(--text-muted)">Integrated Pest Management (IPM) guidelines apply. Suppressed if RH &lt; 85%.</div>
          </div>
        </div>

        <!-- MicroSD Hardware Presence & Health Section -->
        <div class="hardware-card" id="sdAuditCard">
          <div class="hw-info">
            <div class="hw-title">
              <span class="pulsing-dot" id="sdBadgeDot" style="color: var(--accent-amber)"></span>
              <span id="sdTitleText">MicroSD Card Slot: Checking...</span>
            </div>
            <div class="hw-desc" id="sdDetailText">
              Querying camera slot for FAT32 filesystem and offline neural weights...
            </div>
          </div>
          <button class="btn-hw-check" onclick="pollMeshNow()">RE-CHECK HARDWARE</button>
        </div>

        <!-- Collapsible System Log -->
        <div class="activity-container">
          <div class="activity-header">
            <span>Edge System Activity Stream</span>
            <span style="font-size: 10px; color: var(--accent-emerald);">Live Mesh Daemon</span>
          </div>
          <div class="terminal-feed" id="terminal">
            <div class="log-line"><span class="log-t">[SYSTEM]</span> <span class="log-tag-info">INIT</span> KRISHI-DRISHTI Edge AI Server daemon loaded.</div>
            <div class="log-line"><span class="log-t">[SYSTEM]</span> <span class="log-tag-info">MESH</span> SoftAP gateway target: http://192.168.4.1</div>
          </div>
        </div>

      </div>

    </div>

    <!-- Hidden Offscreen Canvas for Neural Pre-processing -->
    <canvas id="offscreenCanvas" width="128" height="128" style="display: none;"></canvas>

    <footer class="app-footer">
      KRISHI-DRISHTI &bull; Autonomous Offline Edge AI Plant Telemetry &bull; Powered by MobileNetV3 Float16
    </footer>

  </div>

  <script>
    let isRunning = false;
    let pollInterval = null;
    let lastProcessedScanId = 0;
    let wakeLock = null;
    let keepAliveAudio = null;
    let totalScansProcessed = 0;

    let tfliteModel = null;
    let modelReady = false;
    let isModelLoading = false;
    let currentTelemetry = null;

    const CAMERA_STATUS_URL   = "http://192.168.4.1/api/status";
    const CAMERA_IMAGE_URL    = "http://192.168.4.1/image?id=";
    const CAMERA_DIAG_SET_URL = "http://192.168.4.1/api/diagnosis/set";

    // STRICT CLASS ORDERING - 100% IDENTICAL 1:1 MATCH WITH labels.json & MODEL OUTPUT
    const KB_CLASSES = [
      {
        id: 0,
        name: "Tomato___Late_blight",
        crop: "Tomato",
        disease: "Late Blight",
        pathogen: "Phytophthora infestans (Oomycete)",
        status: "INFECTED",
        organic: "Neem Oil 5ml/L + Trichoderma viride. Prune lower canopy to enhance aeration.",
        chemical: "Cymoxanil 8% + Mancozeb 64% WP @ 2.5g/L or Ridomil Gold @ 2g/L"
      },
      {
        id: 1,
        name: "Tomato___Early_blight",
        crop: "Tomato",
        disease: "Early Blight",
        pathogen: "Alternaria solani (Fungus)",
        status: "WARNING",
        organic: "Baking soda 5g/L + compost tea. Mulch soil to prevent rain splash dispersal.",
        chemical: "Chlorothalonil 75% WP @ 2g/L or Copper Oxychloride 3g/L"
      },
      {
        id: 2,
        name: "Tomato___healthy",
        crop: "Tomato",
        disease: "Healthy",
        pathogen: "Optimal (Zero Pathogen)",
        status: "HEALTHY",
        organic: "Maintain drip irrigation schedule & balanced 19:19:19 NPK foliar nutrition.",
        chemical: "No chemical fungicides required."
      },
      {
        id: 3,
        name: "Potato___Late_blight",
        crop: "Potato",
        disease: "Late Blight",
        pathogen: "Phytophthora infestans (Oomycete)",
        status: "INFECTED",
        organic: "Copper soap spray + haulm destruction 10 days pre-harvest to protect tubers.",
        chemical: "Cymoxanil 8% + Mancozeb 64% WP @ 2.5g/L"
      },
      {
        id: 4,
        name: "Potato___Early_blight",
        crop: "Potato",
        disease: "Early Blight",
        pathogen: "Alternaria solani (Fungus)",
        status: "WARNING",
        organic: "Crop rotation with non-solanaceous crops + Neem cake soil drench.",
        chemical: "Azoxystrobin 23% SC @ 1.0ml/L"
      },
      {
        id: 5,
        name: "Potato___healthy",
        crop: "Potato",
        disease: "Healthy",
        pathogen: "Optimal (Zero Pathogen)",
        status: "HEALTHY",
        organic: "Maintain uniform soil hilling to prevent tuber greening & solar exposure.",
        chemical: "No chemical intervention needed."
      }
    ];

    function log(msg, type = "info") {
      const term = document.getElementById("terminal");
      if (!term) return;
      const d = document.createElement("div");
      d.className = "log-line";
      const timeStr = new Date().toLocaleTimeString();
      let tagHtml = `<span class="log-tag-info">INFO</span>`;
      if (type === "ok")   tagHtml = `<span class="log-tag-ok">SUCCESS</span>`;
      if (type === "err")  tagHtml = `<span class="log-tag-err">ERROR</span>`;
      if (type === "ai")   tagHtml = `<span class="log-tag-ai">NEURAL</span>`;
      if (type === "warn") tagHtml = `<span class="log-tag-warn">WARN</span>`;
      d.innerHTML = `<span class="log-t">[${timeStr}]</span> ${tagHtml} <span>${msg}</span>`;
      term.appendChild(d);
      term.scrollTop = term.scrollHeight;
    }

    async function initTFLite(retryCount = 0) {
      if (modelReady || isModelLoading) return;
      isModelLoading = true;

      const engineEl = document.getElementById("valEngine");
      if (engineEl) {
        engineEl.innerText = "INITIALIZING...";
        engineEl.style.color = "var(--accent-amber)";
      }

      try {
        log("Booting bundled WASM TFLite co-processor engine...", "ai");
        if (typeof tflite !== 'undefined' && tflite.setWasmPath) {
          tflite.setWasmPath('/vendor/');
        }

        if (engineEl) {
          engineEl.innerText = "LOADING MODEL...";
          engineEl.style.color = "var(--accent-amber)";
        }

        tfliteModel = await tflite.loadTFLiteModel('/krishi_drishti_model.tflite');
        modelReady = true;
        isModelLoading = false;

        if (engineEl) {
          engineEl.innerText = "TFLITE ACTIVE";
          engineEl.style.color = "var(--accent-emerald)";
        }
        log("MobileNetV3 Edge TFLite core loaded 100% offline.", "ok");
      } catch (err) {
        isModelLoading = false;
        if (engineEl) {
          engineEl.innerText = "AI OFFLINE";
          engineEl.style.color = "var(--accent-rose)";
        }
        log(`TFLite load error: ${err.message}. Retrying...`, "err");
        if (retryCount < 3) {
          setTimeout(() => initTFLite(retryCount + 1), 3000);
        }
      }
    }

    async function requestWakeLock() {
      try {
        if ('wakeLock' in navigator) {
          wakeLock = await navigator.wakeLock.request('screen');
          document.addEventListener('visibilitychange', async () => {
            if (wakeLock !== null && document.visibilityState === 'visible') {
              wakeLock = await navigator.wakeLock.request('screen');
            }
          });
        }
      } catch (err) {}
    }

    function startKeepAliveAudio() {
      try {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        keepAliveAudio = new AudioContext();
        const buffer = keepAliveAudio.createBuffer(1, keepAliveAudio.sampleRate * 1, keepAliveAudio.sampleRate);
        const source = keepAliveAudio.createBufferSource();
        source.buffer = buffer;
        source.loop = true;
        source.connect(keepAliveAudio.destination);
        source.start();
      } catch (e) {}
    }

    function stopKeepAliveAudio() {
      if (keepAliveAudio) {
        try { keepAliveAudio.close(); } catch (e) {}
        keepAliveAudio = null;
      }
    }

    function toggleServer() {
      if (isRunning) {
        stopServer();
      } else {
        startServer();
      }
    }

    function startServer() {
      if (isRunning) return;
      isRunning = true;

      requestWakeLock();
      startKeepAliveAudio();

      const pill = document.getElementById("statusPill");
      if (pill) pill.className = "status-pill pill-running";
      safeSetText("statusText", "INFERENCE ACTIVE");

      const btn = document.getElementById("btnToggle");
      if (btn) {
        btn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg> PAUSE AI SERVER`;
        btn.style.background = "linear-gradient(135deg, #F59E0B, #D97706)";
        btn.style.boxShadow = "0 4px 14px rgba(245, 158, 11, 0.35)";
      }

      log("Edge AI Co-Processor started. Polling softAP mesh...", "ok");
      pollInterval = setInterval(checkCameraForNewScan, 600);
    }

    function stopServer() {
      isRunning = false;
      if (pollInterval) {
        clearInterval(pollInterval);
        pollInterval = null;
      }
      if (wakeLock) {
        try { wakeLock.release(); } catch(e) {}
        wakeLock = null;
      }
      stopKeepAliveAudio();

      const pill = document.getElementById("statusPill");
      if (pill) pill.className = "status-pill pill-stopped";
      safeSetText("statusText", "STANDBY");

      const btn = document.getElementById("btnToggle");
      if (btn) {
        btn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="5 3 19 12 5 21 5 3"/></svg> START AI INFERENCE SERVER`;
        btn.style.background = "linear-gradient(135deg, #10B981, #059669)";
        btn.style.boxShadow = "0 4px 14px rgba(16, 185, 129, 0.35)";
      }

      safeSetText("valCameraLink", "STANDBY");
      safeSetStyle("valCameraLink", "color", "var(--text-dim)");
      safeSetText("valWandLink", "STANDBY");
      safeSetStyle("valWandLink", "color", "var(--text-dim)");

      log("Edge AI Co-Processor paused.", "warn");
    }

    async function pollMeshNow() {
      log("Manually auditing ESP32-CAM hardware & SD slot...", "ai");
      await checkCameraForNewScan();
    }

    async function checkCameraForNewScan() {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 750);

        const res = await fetch(CAMERA_STATUS_URL, { signal: controller.signal });
        clearTimeout(timeoutId);

        if (!res.ok) return;
        const status = await res.json();

        // 1. Camera Gateway Link
        const camEl = document.getElementById("valCameraLink");
        if (camEl) {
          camEl.innerText = "ONLINE (AP)";
          camEl.style.color = "var(--accent-emerald)";
        }

        // 2. MicroSD Card Detection & Verification
        const sdEl = document.getElementById("valSdStatus");
        const sdCard = document.getElementById("sdAuditCard");
        const sdDot = document.getElementById("sdBadgeDot");
        const sdTitle = document.getElementById("sdTitleText");
        const sdDetail = document.getElementById("sdDetailText");

        if (status.sd_ready) {
          const capText = status.sd_capacity_mb ? `${Math.round(status.sd_capacity_mb/1024*10)/10} GB` : "FAT32";
          if (sdEl) {
            sdEl.innerText = `READY (${capText})`;
            sdEl.style.color = "var(--accent-emerald)";
          }
          if (sdCard) sdCard.style.borderColor = "rgba(16, 185, 129, 0.3)";
          if (sdDot) { sdDot.style.color = "var(--accent-emerald)"; }
          if (sdTitle) { sdTitle.innerText = `MicroSD Card: Detected & Mounted (${capText})`; }
          if (sdDetail) {
            sdDetail.innerText = "Camera filesystem active. Offline MobileNetV3 weights & WASM assets available. All shutter scans saved to /scans/.";
          }
          if (!modelReady && !isModelLoading) {
            initTFLite(0);
          }
        } else {
          if (sdEl) {
            sdEl.innerText = "NOT DETECTED";
            sdEl.style.color = "var(--accent-rose)";
          }
          if (sdCard) sdCard.style.borderColor = "rgba(244, 63, 94, 0.4)";
          if (sdDot) { sdDot.style.color = "var(--accent-rose)"; }
          if (sdTitle) { sdTitle.innerText = "MicroSD Card Slot: Card Not Detected"; }
          if (sdDetail) {
            sdDetail.innerHTML = "<b style='color: var(--accent-rose)'>Card missing in camera slot.</b> Ensure a FAT32 Class-10 TF card is inserted, then tap RE-CHECK HARDWARE.";
          }
        }

        // 3. Wand Controller Connectivity
        const wandEl = document.getElementById("valWandLink");
        if (wandEl) {
          if (status.wand_connected) {
            wandEl.innerText = "CONNECTED";
            wandEl.style.color = "var(--accent-emerald)";
          } else {
            wandEl.innerText = "WAND OFF";
            wandEl.style.color = "var(--text-dim)";
          }
        }

        // 4. Ingest Ambient Telemetry
        if (status.telemetry_available) {
          currentTelemetry = {
            humidity: status.humidity,
            temperature: status.temperature
          };
        } else {
          currentTelemetry = null;
        }

        // 5. New Shutter Scan Discovery
        if (status.scan_count && status.scan_count > lastProcessedScanId) {
          if (isRunning) {
            await processScanAndRespond(status.scan_count);
          }
        }
      } catch (err) {
        if (!isRunning) {
          safeSetText("valCameraLink", "DISCONNECTED");
          safeSetStyle("valCameraLink", "color", "var(--accent-rose)");
        }
      }
    }

    async function processScanAndRespond(scanId) {
      lastProcessedScanId = scanId;
      log(`New Shutter Capture detected: Scan #${scanId}`, "ai");

      const t0 = performance.now();

      try {
        const img = new Image();
        img.crossOrigin = "anonymous";
        await new Promise((resolve, reject) => {
          img.onload = resolve;
          img.onerror = reject;
          setTimeout(reject, 4000);
          img.src = `${CAMERA_IMAGE_URL}${scanId}&t=${Date.now()}`;
        });

        const leafImg = document.getElementById("leafImg");
        const placeholder = document.getElementById("thumbPlaceholder");
        if (leafImg) {
          leafImg.src = img.src;
          leafImg.style.display = "block";
        }
        if (placeholder) {
          placeholder.style.display = "none";
        }

        log(`Scan #${scanId} loaded into RAM. Running neural inference...`, "ai");
        const diag = await runEdgeInference(img);
        const elapsed = Math.round(performance.now() - t0);

        updateMetricsAndUI(diag, elapsed, scanId);
        playAudioChime();

        log(`Diagnosis: ${diag.crop} - ${diag.disease} (${diag.confidence}%, H=${diag.entropy}) in ${elapsed}ms`, "ok");
        log(`Advisory: ${diag.organic}`);

        const setUrl = `${CAMERA_DIAG_SET_URL}?scan_id=${scanId}&crop=${encodeURIComponent(diag.crop)}&disease=${encodeURIComponent(diag.disease)}&confidence=${diag.confidence}&status=${encodeURIComponent(diag.status)}&organic=${encodeURIComponent(diag.organic)}&chemical=${encodeURIComponent(diag.chemical)}`;

        try {
          const syncRes = await fetch(setUrl);
          if (syncRes.ok) {
            log(`>> TELEMETRY SYNCED TO CONTROLLER WAND OLED [Scan #${scanId}] <<`, "ok");
          } else {
            log(`[SYNC REJECTED] HTTP ${syncRes.status}`, "warn");
          }
        } catch (syncErr) {
          log(`Failed to sync to wand: ${syncErr.message}`, "err");
        }

      } catch (err) {
        log(`Failed to process Scan #${scanId}: ${err.message}`, "err");
      }
    }

    async function runEdgeInference(imgElement) {
      const cvs = document.getElementById("offscreenCanvas");
      const ctx = cvs.getContext("2d", { willReadFrequently: true });
      ctx.drawImage(imgElement, 0, 0, 128, 128);

      // 1. Biological Chlorophyll Foliar & Non-Leaf / Selfie Screening Check
      const frameData = ctx.getImageData(0, 0, 128, 128);
      const data = frameData.data;
      let totalPixels = 128 * 128;
      let greenChlorophyllPixels = 0;
      let necroticLesionPixels = 0;
      let humanSkinPixels = 0;
      let darkVoidPixels = 0;

      for (let i = 0; i < data.length; i += 4) {
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];

        // A. Chlorophyll foliar tissue (green must be competitive with red and higher than blue)
        if (g > 32 && g >= r * 0.90 && g > b * 1.02) {
          greenChlorophyllPixels++;
        }
        // B. Fungal necrotic tissue (blight spots - dark brown/olive with bounded red/green balance)
        else if (r > 40 && g > 30 && b < 110 && r >= g && (r - g) < 50 && (r + g) > (2.2 * b)) {
          necroticLesionPixels++;
        }

        // C. Biometric Human Skin Tone Filter (Selfie / Face / Hand detection)
        if (r > 95 && g > 40 && b > 20 && r > g && g > b && (r - g) > 12 && (r - b) > 20) {
          humanSkinPixels++;
        }

        // D. Peripheral dark void / lens cap
        if (r < 30 && g < 30 && b < 30) {
          darkVoidPixels++;
        }
      }

      const greenRatio = greenChlorophyllPixels / totalPixels;
      const skinRatio = humanSkinPixels / totalPixels;
      const voidRatio = darkVoidPixels / totalPixels;
      const totalFoliarRatio = (greenChlorophyllPixels + necroticLesionPixels) / totalPixels;

      // 1. Reject Human Face / Selfie / Hand
      if (skinRatio > 0.12 && greenRatio < 0.08) {
        return {
          crop: "Invalid",
          disease: "No Leaf Detected",
          pathogen: "Non-Botanical Subject: Human face / skin detected in frame",
          confidence: "0.0",
          status: "UNCERTAIN",
          organic: "KRISHI-DRISHTI is strictly calibrated for Solanaceae foliar pathology.",
          chemical: "Position optical shroud over a tomato or potato crop leaf.",
          entropy: "0.00"
        };
      }

      // 2. Reject Lens Cap / Complete Darkness
      if (voidRatio > 0.75) {
        return {
          crop: "Invalid",
          disease: "No Leaf Detected",
          pathogen: "Excessive darkness / Lens cap or closed shroud detected",
          confidence: "0.0",
          status: "UNCERTAIN",
          organic: "Remove lens cap and ensure target leaf is adequately illuminated.",
          chemical: "Position wand 10cm from leaf surface and re-scan.",
          entropy: "0.00"
        };
      }

      // 3. Reject Ambient Surfaces, Backgrounds & Non-Plant Objects (requires minimum chlorophyll)
      if (greenRatio < 0.06 || totalFoliarRatio < 0.12) {
        return {
          crop: "Invalid",
          disease: "No Leaf Detected",
          pathogen: "Frame does not contain plant foliage or leaf canopy",
          confidence: "0.0",
          status: "UNCERTAIN",
          organic: "Target camera directly at symptomatic Solanaceae foliage.",
          chemical: "Position wand 10cm from leaf surface and re-scan.",
          entropy: "0.00"
        };
      }

      // 2. Genuine MobileNetV3 Float16 WASM Inference
      let probs = [];
      if (modelReady && tfliteModel) {
        let tfImg = null;
        let inputTensor = null;
        let output = null;
        try {
          tfImg = tf.browser.fromPixels(cvs);
          inputTensor = tfImg.toFloat().expandDims(0);
          output = tfliteModel.predict(inputTensor);
          probs = Array.from(output.dataSync());
        } finally {
          if (tfImg) tfImg.dispose();
          if (inputTensor) inputTensor.dispose();
          if (output) output.dispose();
        }
      } else {
        return {
          crop: "System Notice",
          disease: "AI Engine Unavailable",
          pathogen: "MobileNetV3 TFLite model is not ready in browser",
          confidence: "0.0",
          status: "UNCERTAIN",
          organic: "Ensure phone is connected to wand Wi-Fi and model is loaded.",
          chemical: "Consult local Krishi Vigyan Kendra (KVK) agronomist.",
          entropy: "0.00"
        };
      }

      // 3. Shannon Entropy Calculation: H = -sum(p * ln(p))
      let entropy = 0.0;
      for (const p of probs) {
        if (p > 1e-6) entropy -= p * Math.log(p);
      }

      // 4. Argmax
      let maxIdx = 0;
      let maxProb = probs[0];
      for (let i = 1; i < probs.length; i++) {
        if (probs[i] > maxProb) {
          maxProb = probs[i];
          maxIdx = i;
        }
      }
      const confPercent = (maxProb * 100).toFixed(1);

      // Decision margin calculation (top1 - top2)
      const sortedProbs = probs.slice().sort((a, b) => b - a);
      const margin = sortedProbs[0] - (sortedProbs.length > 1 ? sortedProbs[1] : 0.0);

      // 5. Scientific Multi-Tier Uncertainty Gating & Advisory
      const match = KB_CLASSES[maxIdx];
      let chemRec = match.chemical;
      // Microclimate-to-Diagnosis Cross-Gating
      if (match.disease.includes("Late Blight") && currentTelemetry && currentTelemetry.humidity > 0 && currentTelemetry.humidity < 85.0) {
        chemRec = `WITHHELD: Low RH (${Math.round(currentTelemetry.humidity)}%). Spores dormant under dry canopy (requires RH >= 85%). Suppressing fungicide; inspect for abiotic chlorosis.`;
      }

      // Tier 1: High-Confidence Definitive Diagnosis
      if (maxProb >= 0.50 && entropy <= 1.45 && margin >= 0.12) {
        return {
          crop: match.crop,
          disease: match.disease,
          pathogen: match.pathogen,
          confidence: confPercent,
          status: match.status,
          organic: match.organic,
          chemical: chemRec,
          entropy: entropy.toFixed(2)
        };
      }

      // Tier 2: Suspected Diagnosis with Active Gating (e.g. real-world noisy/shaded photos at 30-50% conf)
      if (maxProb >= 0.30 || margin >= 0.05) {
        return {
          crop: match.crop,
          disease: `${match.disease} (Suspected / Ambiguous)`,
          pathogen: `${match.pathogen} [Early lesion / low contrast sample]`,
          confidence: confPercent,
          status: "UNCERTAIN",
          organic: `Foliar symptoms suggest suspected ${match.crop} ${match.disease} (${confPercent}%). Prune isolated symptomatic leaflets; ensure canopy airflow.`,
          chemical: `WITHHELD (Low Confidence ${confPercent}%): Do not spray chemical fungicides without secondary symptom confirmation or agronomist review. Retake photo under direct sunlight at 10cm.`,
          entropy: entropy.toFixed(2)
        };
      }

      // Tier 3: Out-of-Distribution or Non-Target Rejection (< 30% confidence)
      return {
        crop: "Uncertain",
        disease: "Low Confidence / Ambiguous",
        pathogen: "Ambiguous foliar pattern or non-target species",
        confidence: confPercent,
        status: "UNCERTAIN",
        organic: "Hold wand steady at 10cm distance from leaf.",
        chemical: "Ensure uniform solar illumination without shadow or blurry focus.",
        entropy: entropy.toFixed(2)
      };
    }

    function safeSetText(id, text) {
      const el = document.getElementById(id);
      if (el) el.innerText = text;
    }

    function safeSetHTML(id, html) {
      const el = document.getElementById(id);
      if (el) el.innerHTML = html;
    }

    function safeSetStyle(id, prop, val) {
      const el = document.getElementById(id);
      if (el && el.style) el.style[prop] = val;
    }

    function updateMetricsAndUI(diag, latency, scanId) {
      totalScansProcessed++;
      safeSetText("valScanCount", totalScansProcessed);
      safeSetText("valLatency", `${latency} ms`);
      safeSetHTML("scanTimestamp", `SCAN #${scanId} &bull; ${new Date().toLocaleTimeString()} (${latency}ms)`);

      safeSetText("diagPrimary", `${diag.crop}: ${diag.disease}`);
      safeSetText("diagPathogen", `Pathogen: ${diag.pathogen}`);
      
      const confEl = document.getElementById("diagConfidence");
      if (confEl) {
        confEl.innerText = `Confidence: ${diag.confidence}% | Entropy: ${diag.entropy} | Latency: ${latency}ms | Status: ${diag.status}`;
        if (diag.status === "INFECTED") {
          confEl.style.color = "var(--accent-rose)";
          confEl.style.background = "var(--accent-rose-dim)";
          confEl.style.borderColor = "rgba(244, 63, 94, 0.3)";
        } else if (diag.status === "WARNING") {
          confEl.style.color = "var(--accent-amber)";
          confEl.style.background = "var(--accent-amber-dim)";
          confEl.style.borderColor = "rgba(245, 158, 11, 0.3)";
        } else if (diag.status === "UNCERTAIN") {
          confEl.style.color = "var(--accent-cyan)";
          confEl.style.background = "rgba(6, 182, 212, 0.15)";
          confEl.style.borderColor = "rgba(6, 182, 212, 0.3)";
        } else {
          confEl.style.color = "var(--accent-emerald)";
          confEl.style.background = "var(--accent-emerald-dim)";
          confEl.style.borderColor = "rgba(16, 185, 129, 0.3)";
        }
      }

      safeSetText("rxBio", diag.organic);
      safeSetText("rxChem", `Chemical: ${diag.chemical}`);
    }

    async function simulateFieldScan() {
      const demoScanId = (lastProcessedScanId || 0) + 1;
      lastProcessedScanId = demoScanId;
      log(`[DEMO] Triggering test scan #${demoScanId} on sample leaf...`, "ai");
      await testRealLeaf('/sample_leaves/late_blight_512.jpg', 'Field Demo Sample: Late Blight');
    }

    async function testRealLeaf(url, labelName) {
      const demoScanId = (lastProcessedScanId || 0) + 1;
      lastProcessedScanId = demoScanId;
      log(`[EXHIBITION] Loading real leaf image: ${labelName}...`, "ai");

      try {
        const img = new Image();
        img.crossOrigin = "anonymous";
        await new Promise((resolve, reject) => {
          img.onload = resolve;
          img.onerror = () => reject(new Error("Could not load " + url));
          img.src = `${url}?t=${Date.now()}`;
        });

        const leafImg = document.getElementById("leafImg");
        const placeholder = document.getElementById("thumbPlaceholder");
        if (leafImg) {
          leafImg.src = img.src;
          leafImg.style.display = "block";
        }
        if (placeholder) {
          placeholder.style.display = "none";
        }

        const t0 = performance.now();
        const diag = await runEdgeInference(img);
        const latency = Math.round(performance.now() - t0);

        updateMetricsAndUI(diag, latency, demoScanId);
        playAudioChime();
        log(`[NEURAL VERIFIED] ${diag.crop}: ${diag.disease} (${diag.confidence}%, H=${diag.entropy}) in ${latency}ms`, "ok");
        return diag;
      } catch (err) {
        log(`Error diagnosing ${labelName}: ${err.message}`, "err");
        console.error(err);
        return null;
      }
    }

    function handleLeafUpload(event) {
      const file = event.target.files[0];
      if (!file) return;

      const demoScanId = (lastProcessedScanId || 0) + 1;
      lastProcessedScanId = demoScanId;
      log(`[CUSTOM PHOTO] Loading: ${file.name} (${Math.round(file.size/1024)} KB)...`, "ai");

      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const img = new Image();
          img.onload = async () => {
            const leafImg = document.getElementById("leafImg");
            const placeholder = document.getElementById("thumbPlaceholder");
            if (leafImg) {
              leafImg.src = img.src;
              leafImg.style.display = "block";
            }
            if (placeholder) {
              placeholder.style.display = "none";
            }

            const t0 = performance.now();
            const diag = await runEdgeInference(img);
            const latency = Math.round(performance.now() - t0);

            updateMetricsAndUI(diag, latency, demoScanId);
            playAudioChime();
            log(`[CUSTOM DIAGNOSIS] ${diag.crop}: ${diag.disease} (${diag.confidence}%, H=${diag.entropy}) in ${latency}ms`, "ok");
          };
          img.onerror = () => {
            log(`Failed to decode uploaded image: ${file.name}`, "err");
          };
          img.src = e.target.result;
        } catch (err) {
          log(`Error processing uploaded photo: ${err.message}`, "err");
        }
      };
      reader.onerror = () => {
        log(`Failed to read file from disk: ${file.name}`, "err");
      };
      reader.readAsDataURL(file);
    }

    function playAudioChime() {
      try {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        const audioCtx = new AudioContext();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
        osc.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.12); // A5
        gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.18);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.2);
      } catch (e) {}
    }

    // Auto-initialize TFLite and Hardware Status Watchdog on page load
    function initHardwareWatchdog() {
      // Immediate hardware detection (MicroSD & SoftAP Gateway)
      checkCameraForNewScan();
      // Continuous background hardware polling every 1200ms when server in standby
      setInterval(() => {
        if (!isRunning) {
          checkCameraForNewScan();
        }
      }, 1200);
    }

    if (document.readyState === 'loading') {
      window.addEventListener("DOMContentLoaded", () => {
        initTFLite(0);
        initHardwareWatchdog();
      });
    } else {
      initTFLite(0);
      initHardwareWatchdog();
    }
    window.addEventListener("load", () => {
      if (!modelReady && typeof tflite !== 'undefined') initTFLite(0);
      checkCameraForNewScan();
    });
  </script>
</body>
</html>)rawliteral";

// --------------------------------------------------
// EMBEDDED LEAF PHOTO GALLERY & VIEWFINDER (SERVED AT /gallery)
// --------------------------------------------------
const char GALLERY_HTML[] PROGMEM = R"rawliteral(<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>KRISHI-DRISHTI | Leaf Photo Gallery</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #0a0e17; color: #f1f5f9; padding: 14px; min-height: 100vh; }
    .header { text-align: center; padding: 14px 0 10px; border-bottom: 1px solid #1e293b; margin-bottom: 14px; }
    .title { font-size: 20px; font-weight: 800; color: #10b981; letter-spacing: 1px; }
    .subtitle { font-size: 11px; color: #94a3b8; margin-top: 3px; }
    .nav-bar { display: flex; gap: 8px; margin-bottom: 14px; }
    .nav-btn { flex: 1; padding: 10px; border-radius: 8px; font-size: 12px; font-weight: 700; text-align: center; text-decoration: none; border: 1px solid #1e293b; color: #f1f5f9; background: #131c2e; }
    .nav-btn-active { background: rgba(16,185,129,0.2); border-color: #10b981; color: #34d399; }
    .stats-bar { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin-bottom: 14px; }
    .stat-box { background: #131c2e; border: 1px solid #1e293b; border-radius: 8px; padding: 8px; text-align: center; }
    .stat-val { font-size: 14px; font-weight: 800; color: #fff; }
    .stat-lbl { font-size: 9px; color: #64748b; text-transform: uppercase; margin-top: 2px; }
    .actions { display: flex; gap: 8px; margin-bottom: 14px; }
    .btn { padding: 12px; border-radius: 8px; font-size: 12px; font-weight: 700; cursor: pointer; border: none; text-align: center; flex: 1; }
    .btn-capture { background: #10b981; color: #042f1a; }
    .btn-viewfinder { background: #0284c7; color: #fff; }
    .vf-box { display: none; margin-bottom: 14px; border-radius: 10px; overflow: hidden; border: 1px solid #1e293b; background: #000; text-align: center; }
    .vf-box img { width: 100%; height: auto; display: block; }
    .gallery-list { display: flex; flex-direction: column; gap: 8px; }
    .card { background: #131c2e; border: 1px solid #1e293b; border-radius: 8px; padding: 10px 12px; display: flex; justify-content: space-between; align-items: center; }
    .card-name { font-size: 13px; font-weight: 700; color: #f1f5f9; }
    .card-sub { font-size: 10px; color: #64748b; margin-top: 2px; }
    .card-actions { display: flex; gap: 6px; }
    .btn-sm { padding: 5px 8px; border-radius: 5px; font-size: 11px; font-weight: 600; text-decoration: none; border: none; cursor: pointer; }
    .btn-view { background: #0284c7; color: #fff; }
    .btn-dl { background: #10b981; color: #042f1a; }
    .btn-del { background: rgba(239,68,68,0.2); color: #f87171; border: 1px solid rgba(239,68,68,0.3); }
  </style>
</head>
<body>
  <div class="header">
    <div class="title">KRISHI-DRISHTI</div>
    <div class="subtitle">MicroSD High-Resolution Leaf Gallery</div>
  </div>

  <div class="nav-bar">
    <a href="/" class="nav-btn">🧠 AI Server Daemon</a>
    <a href="/gallery" class="nav-btn nav-btn-active">📷 Stored Scans</a>
  </div>

  <div class="stats-bar">
    <div class="stat-box"><div class="stat-val" id="scansCount">-</div><div class="stat-lbl">Photos</div></div>
    <div class="stat-box"><div class="stat-val">UXGA</div><div class="stat-lbl">1600x1200</div></div>
    <div class="stat-box"><div class="stat-val" style="color:#10b981;">1-BIT SD</div><div class="stat-lbl">DMA Safe</div></div>
  </div>

  <div class="actions">
    <button class="btn btn-capture" onclick="manualCapture()">📸 SNAP LEAF</button>
    <button class="btn btn-viewfinder" id="btnVf" onclick="toggleViewfinder()">📹 LIVE VIEWFINDER</button>
  </div>

  <div class="vf-box" id="vfBox">
    <img id="vfImg" src="" alt="Live Viewfinder Stream">
    <div style="padding: 6px; font-size: 10px; color: #94a3b8;">Center leaf inside camera field of view</div>
  </div>

  <div class="gallery-list" id="galleryList">
    <div style="text-align:center; padding: 20px; color: #64748b; font-size: 12px;">Loading scans from MicroSD...</div>
  </div>

  <script>
    let vfActive = false;
    let vfTimer = null;

    async function loadScans() {
      try {
        const res = await fetch('/api/scans?t=' + Date.now());
        const data = await res.json();
        document.getElementById('scansCount').innerText = data.scans ? data.scans.length : 0;
        const list = document.getElementById('galleryList');
        if (!data.scans || data.scans.length === 0) {
          list.innerHTML = '<div style="text-align:center; padding: 20px; color: #64748b; font-size: 12px;">No leaf scans stored on MicroSD card yet.</div>';
          return;
        }
        let html = '';
        data.scans.forEach(s => {
          html += `<div class="card">
            <div>
              <div class="card-name">Scan #${s.id}</div>
              <div class="card-sub">${s.file}</div>
            </div>
            <div class="card-actions">
              <a href="/image?id=${s.id}" target="_blank" class="btn-sm btn-view">View</a>
              <a href="/image?id=${s.id}&download=1" class="btn-sm btn-dl">Save</a>
              <button onclick="deleteScan(${s.id})" class="btn-sm btn-del">X</button>
            </div>
          </div>`;
        });
        list.innerHTML = html;
      } catch (e) {
        document.getElementById('galleryList').innerHTML = '<div style="text-align:center; color:#f87171; font-size:12px;">Error contacting camera SD card.</div>';
      }
    }

    async function manualCapture() {
      const btn = document.querySelector('.btn-capture');
      btn.innerText = '📸 FLASHING & CAPTURING...';
      btn.disabled = true;
      try {
        const res = await fetch('/api/capture');
        const data = await res.json();
        alert('Scan #' + data.scan_id + ' captured and saved to SD card!');
        loadScans();
      } catch (e) {
        alert('Capture failed: ' + e.message);
      }
      btn.innerText = '📸 SNAP LEAF';
      btn.disabled = false;
    }

    async function deleteScan(id) {
      if (!confirm('Delete Scan #' + id + '?')) return;
      await fetch('/api/delete?id=' + id);
      loadScans();
    }

    function toggleViewfinder() {
      vfActive = !vfActive;
      const box = document.getElementById('vfBox');
      const btn = document.getElementById('btnVf');
      if (vfActive) {
        box.style.display = 'block';
        btn.innerText = '⏹ STOP VIEWFINDER';
        runVf();
      } else {
        box.style.display = 'none';
        btn.innerText = '📹 LIVE VIEWFINDER';
        clearTimeout(vfTimer);
      }
    }

    function runVf() {
      if (!vfActive) return;
      const img = document.getElementById('vfImg');
      img.src = '/api/preview?t=' + Date.now();
      vfTimer = setTimeout(runVf, 400);
    }

    loadScans();
  </script>
</body>
</html>)rawliteral";

// --------------------------------------------------
// SCAN NUMBER RECOVERY ON BOOT
// --------------------------------------------------
void findNextScanNumber() {
  if (!sdReady) return;
  if (scanCounter > 0) return;
  scanCounter = 0;

  while (scanCounter < 10000) {
    uint32_t nextId = scanCounter + 1;
    char filename[32];
    snprintf(filename, sizeof(filename), "/scan_%06lu.jpg", (unsigned long)nextId);
    if (!SD_MMC.exists(filename)) break;
    scanCounter = nextId;
  }
  Serial.printf("[SD] Recovered next scan ID: %lu\n", (unsigned long)(scanCounter + 1));
}

// --------------------------------------------------
// CAMERA DRIVER INITIALISATION (OV5640 / OV2640 DUAL)
// --------------------------------------------------
bool initialiseCamera() {
  Serial.println("[CAM] Initialising image sensor...");
  psramAvailable = psramFound();
  Serial.printf("[CAM] PSRAM available: %s\n", psramAvailable ? "YES" : "NO");

  camera_config_t config = {};
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer   = LEDC_TIMER_0;
  config.pin_d0       = Y2_GPIO_NUM;
  config.pin_d1       = Y3_GPIO_NUM;
  config.pin_d2       = Y4_GPIO_NUM;
  config.pin_d3       = Y5_GPIO_NUM;
  config.pin_d4       = Y6_GPIO_NUM;
  config.pin_d5       = Y7_GPIO_NUM;
  config.pin_d6       = Y8_GPIO_NUM;
  config.pin_d7       = Y9_GPIO_NUM;
  config.pin_xclk     = XCLK_GPIO_NUM;
  config.pin_pclk     = PCLK_GPIO_NUM;
  config.pin_vsync    = VSYNC_GPIO_NUM;
  config.pin_href     = HREF_GPIO_NUM;
  config.pin_sccb_sda = SIOD_GPIO_NUM;
  config.pin_sccb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn     = PWDN_GPIO_NUM;
  config.pin_reset    = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.pixel_format = PIXFORMAT_JPEG;
  if (psramAvailable) {
    config.frame_size   = FRAMESIZE_UXGA;  // 1600 x 1200
    config.jpeg_quality = 10;
    config.fb_count     = 2;
    config.grab_mode    = CAMERA_GRAB_LATEST;
    config.fb_location  = CAMERA_FB_IN_PSRAM;
  } else {
    Serial.println("[CAM WARN] No PSRAM detected. Falling back to SVGA (800x600)");
    config.frame_size   = FRAMESIZE_SVGA;  // 800 x 600
    config.jpeg_quality = 12;
    config.fb_count     = 1;
    config.grab_mode    = CAMERA_GRAB_WHEN_EMPTY;
    config.fb_location  = CAMERA_FB_IN_DRAM;
  }

  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    Serial.printf("[CAM ERROR] esp_camera_init failed: 0x%x\n", err);
    return false;
  }

  sensor_t* s = esp_camera_sensor_get();
  if (s != nullptr) {
    if (s->id.PID == 0x5640) sensorModel = "OV5640 (5MP)";
    else if (s->id.PID == 0x2640) sensorModel = "OV2640 (2MP)";
    else sensorModel = "OmniVision 0x" + String(s->id.PID, HEX);

    Serial.printf("[CAM] Sensor Identified: %s (PID: 0x%04X)\n", sensorModel.c_str(), s->id.PID);
    s->set_brightness(s, 0);
    s->set_contrast(s, 0);
    s->set_saturation(s, 0);
  }

  // Warmup test frame
  camera_fb_t* fb = esp_camera_fb_get();
  if (fb) {
    Serial.printf("[CAM] Test frame OK: %u x %u (%u bytes)\n", fb->width, fb->height, fb->len);
    esp_camera_fb_return(fb);
    return true;
  }
  return false;
}

// --------------------------------------------------
// MICROSD IN 1-BIT MODE (DMA-PROTECTED)
// --------------------------------------------------
static uint64_t cachedSdCardSizeMB = 0;

bool initialiseSD() {
  if (sdReady && cachedSdCardSizeMB > 0) return true;
  Serial.println("[SD] Mounting MicroSD in 1-bit mode (20MHz)...");
  if (!SD_MMC.begin("/sdcard", true, false, 20000, 5)) {
    Serial.println("[SD] 20MHz mount failed, retrying at 10MHz...");
    if (!SD_MMC.begin("/sdcard", true, false, 10000, 5)) {
      Serial.println("[SD WARN] MicroSD card not mounted (insert Class 10 card)");
      return false;
    }
  }
  uint8_t cardType = SD_MMC.cardType();
  if (cardType == CARD_NONE) {
    Serial.println("[SD] No card in slot");
    SD_MMC.end();
    return false;
  }
  cachedSdCardSizeMB = SD_MMC.cardSize() / (1024ULL * 1024ULL);
  Serial.printf("[SD] MicroSD Fast Mounted! Capacity: %llu MB\n", cachedSdCardSizeMB);
  return true;
}

// --------------------------------------------------
// HTTP HANDLERS
// --------------------------------------------------
void handleRoot() {
  server.sendHeader("Cache-Control", "no-cache, no-store, must-revalidate");
  if (sdReady && SD_MMC.exists("/index.html")) {
    File f = SD_MMC.open("/index.html", FILE_READ);
    server.sendHeader("Access-Control-Allow-Origin", "*");
    server.streamFile(f, "text/html");
    f.close();
    return;
  }
  if (sdReady && SD_MMC.exists("/krishi_ai_server.html")) {
    File f = SD_MMC.open("/krishi_ai_server.html", FILE_READ);
    server.sendHeader("Access-Control-Allow-Origin", "*");
    server.streamFile(f, "text/html");
    f.close();
    return;
  }
  server.send_P(200, "text/html", AI_SERVER_HTML);
}

void handleGallery() {
  server.sendHeader("Cache-Control", "no-cache, no-store, must-revalidate");
  server.send_P(200, "text/html", GALLERY_HTML);
}

void handleStatus() {
  uint64_t sizeMB = sdReady ? cachedSdCardSizeMB : 0;
  int clientCount = WiFi.softAPgetStationNum();
  bool wandConnected = (clientCount >= 1) || (lastWandActivityMs > 0 && (millis() - lastWandActivityMs < 30000));

  String json = "{";
  json += "\"device\":\"KRISHI-DRISHTI-CAM\",";
  json += "\"camera_ready\":" + String(cameraReady ? "true" : "false") + ",";
  json += "\"sd_ready\":" + String(sdReady ? "true" : "false") + ",";
  json += "\"sd_capacity_mb\":" + String((unsigned long)sizeMB) + ",";
  json += "\"wand_connected\":" + String(wandConnected ? "true" : "false") + ",";
  json += "\"psram_available\":" + String(psramAvailable ? "true" : "false") + ",";
  json += "\"sensor\":\"" + sensorModel + "\",";
  json += "\"scan_count\":" + String(scanCounter) + ",";
  json += "\"clients\":" + String(clientCount) + ",";
  json += "\"diagnosis_ready\":" + String(diagnosisReady ? "true" : "false") + ",";
  json += "\"telemetry_available\":" + String(canopyTelemetryPresent ? "true" : "false") + ",";
  json += "\"humidity\":" + String(lastCanopyHum, 1) + ",";
  json += "\"temperature\":" + String(lastCanopyTemp, 1);
  json += "}";
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.send(200, "application/json", json);
}

void handleCapture() {
  lastWandActivityMs = millis();
  // Reset telemetry availability for each new scan to prevent stale readings
  canopyTelemetryPresent = false;
  lastCanopyHum = 0.0f;
  lastCanopyTemp = 0.0f;

  if (server.hasArg("hum") && server.hasArg("temp")) {
    float h = server.arg("hum").toFloat();
    float t = server.arg("temp").toFloat();
    if (h > 0.0f && h <= 100.0f && t >= -10.0f && t <= 65.0f) {
      lastCanopyHum = h;
      lastCanopyTemp = t;
      canopyTelemetryPresent = true;
    }
  }
  if (!cameraReady) {
    server.sendHeader("Access-Control-Allow-Origin", "*");
    server.send(503, "application/json", "{\"status\":\"error\",\"message\":\"camera_offline\"}");
    return;
  }

  if (!sdReady) {
    server.sendHeader("Access-Control-Allow-Origin", "*");
    server.send(503, "application/json", "{\"status\":\"error\",\"message\":\"sd_storage_offline\"}");
    return;
  }

  diagnosisReady = false; // Reset diagnosis flag for newly captured leaf

  // Pulse Flash LED for illumination
  digitalWrite(FLASH_LED_PIN, HIGH);
  // Flush pre-flash buffered frame so sensor AEC adapts to flash illumination
  camera_fb_t* stale_fb = esp_camera_fb_get();
  if (stale_fb) esp_camera_fb_return(stale_fb);
  delay(80);
  camera_fb_t* fb = esp_camera_fb_get();
  digitalWrite(FLASH_LED_PIN, LOW); // Shut off LED immediately

  if (!fb) {
    server.sendHeader("Access-Control-Allow-Origin", "*");
    server.send(500, "application/json", "{\"status\":\"error\",\"message\":\"capture_failed\"}");
    return;
  }

  uint32_t nextId = scanCounter + 1;
  char filename[32];
  snprintf(filename, sizeof(filename), "/scan_%06lu.jpg", (unsigned long)nextId);

  size_t written = 0;
  File file = SD_MMC.open(filename, FILE_WRITE);
  if (file) {
    written = file.write(fb->buf, fb->len);
    file.close();
  } else {
    Serial.printf("[SD ERROR] Failed to open %s for write!\n", filename);
    esp_camera_fb_return(fb);
    server.sendHeader("Access-Control-Allow-Origin", "*");
    server.send(500, "application/json", "{\"status\":\"error\",\"message\":\"sd_open_failed\"}");
    return;
  }

  // Write verification: reject empty or truncated files
  if (written < 512 || written != fb->len) {
    Serial.printf("[SD ERROR] Frame write incomplete! Expected %u bytes, wrote %u bytes\n", 
                  (unsigned int)fb->len, (unsigned int)written);
    esp_camera_fb_return(fb);
    server.sendHeader("Access-Control-Allow-Origin", "*");
    server.send(500, "application/json", "{\"status\":\"error\",\"message\":\"sd_write_truncated\"}");
    return;
  }

  scanCounter = nextId;
  esp_camera_fb_return(fb);

  String body = "{\"status\":\"success\",\"scan_id\":" + String(scanCounter);
  body += ",\"filename\":\"" + String(filename) + "\",\"bytes\":" + String(written) + "}";

  Serial.printf("[CAPTURE] Scan #%lu saved (%u bytes)\n", (unsigned long)scanCounter, (unsigned int)written);
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.send(200, "application/json", body);
}

void handleGetImage() {
  if (!sdReady) {
    server.send(503, "text/plain", "SD offline");
    return;
  }
  if (isStreaming) {
    server.send(429, "text/plain", "Bus busy");
    return;
  }

  isStreaming = true;
  String filename = "";
  if (server.hasArg("id")) {
    char buf[32];
    snprintf(buf, sizeof(buf), "/scan_%06lu.jpg", (unsigned long)server.arg("id").toInt());
    filename = String(buf);
  } else if (server.hasArg("file")) {
    filename = server.arg("file");
    if (!filename.startsWith("/")) filename = "/" + filename;
  } else {
    isStreaming = false;
    server.send(400, "text/plain", "Missing id");
    return;
  }

  if (!SD_MMC.exists(filename.c_str())) {
    isStreaming = false;
    server.send(404, "text/plain", "Not found");
    return;
  }

  File f = SD_MMC.open(filename.c_str(), FILE_READ);
  if (server.hasArg("download")) {
    server.sendHeader("Content-Disposition", "attachment; filename=\"" + filename.substring(1) + "\"");
  }
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.streamFile(f, "image/jpeg");
  f.close();
  isStreaming = false;
}

void handleListScans() {
  if (!sdReady) {
    server.send(503, "application/json", "{\"status\":\"error\",\"message\":\"sd_offline\"}");
    return;
  }
  String json = "{\"total\":" + String(scanCounter) + ",\"scans\":[";
  bool first = true;
  for (int32_t i = scanCounter; i >= 1; i--) {
    char buf[32];
    snprintf(buf, sizeof(buf), "/scan_%06lu.jpg", (unsigned long)i);
    if (SD_MMC.exists(buf)) {
      if (!first) json += ",";
      json += "{\"id\":" + String(i) + ",\"file\":\"" + String(buf) + "\"}";
      first = false;
    }
  }
  json += "]}";
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.send(200, "application/json", json);
}

void handleDelete() {
  if (!sdReady) {
    server.send(503, "application/json", "{\"status\":\"error\"}");
    return;
  }
  if (server.hasArg("id")) {
    uint32_t id = server.arg("id").toInt();
    char buf[32];
    snprintf(buf, sizeof(buf), "/scan_%06lu.jpg", (unsigned long)id);
    if (SD_MMC.exists(buf)) SD_MMC.remove(buf);
    server.send(200, "application/json", "{\"status\":\"deleted\"}");
  } else {
    server.send(400, "application/json", "{\"status\":\"bad_request\"}");
  }
}

void handleGetDiagnosis() {
  String json = "{";
  json += "\"ready\":" + String(diagnosisReady ? "true" : "false") + ",";
  json += "\"scan_id\":" + String(diagScanId) + ",";
  json += "\"crop\":\"" + diagCrop + "\",";
  json += "\"disease\":\"" + diagDisease + "\",";
  json += "\"confidence\":" + String(diagConfidence, 1) + ",";
  json += "\"status\":\"" + diagStatus + "\",";
  json += "\"organic\":\"" + diagOrganic + "\",";
  json += "\"chemical\":\"" + diagChemical + "\"";
  json += "}";
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.send(200, "application/json", json);
}

void handleSetDiagnosis() {
  uint32_t incomingScanId = 0;
  if (server.hasArg("scan_id")) {
    incomingScanId = server.arg("scan_id").toInt();
  }

  // Reject stale diagnosis payloads to guarantee diagnosis matches active scan
  if (incomingScanId != scanCounter) {
    Serial.printf("[AI WARNING] Rejected stale diagnosis for Scan #%lu (Active scan is #%lu)\n",
                  (unsigned long)incomingScanId, (unsigned long)scanCounter);
    server.sendHeader("Access-Control-Allow-Origin", "*");
    server.send(409, "application/json", "{\"status\":\"error\",\"message\":\"stale_scan_id\",\"active_scan\":" + String(scanCounter) + "}");
    return;
  }

  diagScanId = incomingScanId;
  if (server.hasArg("crop")) diagCrop = server.arg("crop");
  if (server.hasArg("disease")) diagDisease = server.arg("disease");
  if (server.hasArg("confidence")) diagConfidence = server.arg("confidence").toFloat();
  if (server.hasArg("status")) diagStatus = server.arg("status");
  if (server.hasArg("organic")) diagOrganic = server.arg("organic");
  if (server.hasArg("chemical")) diagChemical = server.arg("chemical");

  diagnosisReady = true;

  Serial.println("\n[AI DIAGNOSIS SYNCED FROM POCKET]");
  Serial.printf(" - Scan #%lu | Crop: %s | Condition: %s (%.1f%%)\n", 
                (unsigned long)diagScanId, diagCrop.c_str(), diagDisease.c_str(), diagConfidence);
  Serial.printf(" - Organic Remedy: %s\n", diagOrganic.c_str());
  Serial.printf(" - Chemical Cure: %s\n", diagChemical.c_str());

  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.send(200, "application/json", "{\"status\":\"success\"}");
}

void handlePreview() {
  if (!cameraReady) {
    server.send(503, "text/plain", "Camera offline");
    return;
  }
  camera_fb_t* fb = esp_camera_fb_get();
  if (!fb) {
    server.send(500, "text/plain", "Frame error");
    return;
  }
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.send_P(200, "image/jpeg", (const char*)fb->buf, fb->len);
  esp_camera_fb_return(fb);
}

void handleFlashToggle() {
  if (server.hasArg("state")) {
    int s = server.arg("state").toInt();
    digitalWrite(FLASH_LED_PIN, s ? HIGH : LOW);
    server.send(200, "text/plain", s ? "FLASH_ON" : "FLASH_OFF");
  } else {
    server.send(400, "text/plain", "Missing state");
  }
}

// --------------------------------------------------
// SETUP
// --------------------------------------------------
// --------------------------------------------------
// STATIC FILE STREAMER (SERVES OFFLINE TFLITE & ASSETS FROM SDMMC)
// --------------------------------------------------
void handleStaticFile() {
  String path = server.uri();
  if (path.endsWith("/")) path += "index.html";

  String contentType = "text/plain";
  if (path.endsWith(".html")) contentType = "text/html";
  else if (path.endsWith(".css")) contentType = "text/css";
  else if (path.endsWith(".js")) contentType = "application/javascript";
  else if (path.endsWith(".wasm")) contentType = "application/wasm";
  else if (path.endsWith(".tflite")) contentType = "application/octet-stream";
  else if (path.endsWith(".json")) contentType = "application/json";
  else if (path.endsWith(".png")) contentType = "image/png";
  else if (path.endsWith(".jpg") || path.endsWith(".jpeg")) contentType = "image/jpeg";
  else if (path.endsWith(".svg")) contentType = "image/svg+xml";

  if (!sdReady) {
    server.send(503, "text/plain", "SD offline - Insert MicroSD card in ESP32-CAM slot");
    return;
  }
  if (SD_MMC.exists(path.c_str())) {
    File f = SD_MMC.open(path.c_str(), FILE_READ);
    server.sendHeader("Access-Control-Allow-Origin", "*");
    server.sendHeader("Cache-Control", "public, max-age=86400");
    server.streamFile(f, contentType);
    f.close();
    return;
  }
  server.send(404, "text/plain", "404 Not Found");
}

void setup() {
  Serial.begin(115200);
  setCpuFrequencyMhz(240); // 240MHz performance lock

  pinMode(FLASH_LED_PIN, OUTPUT);
  digitalWrite(FLASH_LED_PIN, LOW);

  Serial.println("\n========================================");
  Serial.println("  KRISHI-DRISHTI :: ESP32-CAM v2.2");
  Serial.println("  Offline-First Edge Agritech Platform");
  Serial.println("========================================");

  cameraReady = initialiseCamera();
  sdReady     = initialiseSD();

  if (sdReady) findNextScanNumber();

  Serial.println("\n[WIFI] Broadcasting SoftAP: KRISHI-DRISHTI...");
  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASSWORD);

  Serial.print("[WIFI] Gateway IP: ");
  Serial.println(WiFi.softAPIP());

  // Web routes
  server.on("/", HTTP_GET, handleRoot);
  server.on("/ai", HTTP_GET, handleRoot);
  server.on("/gallery", HTTP_GET, handleGallery);
  server.on("/api/status", HTTP_GET, handleStatus);
  server.on("/api/capture", HTTP_GET, handleCapture);
  server.on("/image", HTTP_GET, handleGetImage);
  server.on("/api/scans", HTTP_GET, handleListScans);
  server.on("/api/delete", HTTP_GET, handleDelete);
  server.on("/api/diagnosis", HTTP_GET, handleGetDiagnosis);
  server.on("/api/diagnosis/latest", HTTP_GET, handleGetDiagnosis);
  server.on("/api/diagnosis/set", HTTP_GET, handleSetDiagnosis);
  server.on("/api/diagnosis/set", HTTP_POST, handleSetDiagnosis);
  server.on("/api/preview", HTTP_GET, handlePreview);
  server.on("/api/flash", HTTP_GET, handleFlashToggle);

    server.onNotFound(handleStaticFile);
  server.begin();
  Serial.println("[HTTP] Server listening on http://192.168.4.1/\n");
}

// --------------------------------------------------
// MAIN LOOP
// --------------------------------------------------
void loop() {
  server.handleClient();
  delay(2);
}
