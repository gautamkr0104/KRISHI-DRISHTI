﻿KRISHI-DRISHTI SD CARD - READY TO USE
=====================================

Card contents:
  index.html                  - dashboard (copy of the AI server page)
  krishi_ai_server.html       - main AI dashboard, served by the camera on boot
  krishi_drishti_model.tflite - neural model, sha256 prefix a2a4c9f6134ec0de
                                (round-9 mined-hard-negative OE build, 2026-11-17)
  labels.json                 - class order contract (must match model output)
  vendor/                     - offline TensorFlow.js + TFLite WASM runtimes
  sample_leaves/              - demo foliage for exhibition scans
  scans/ + scan_0000NN.jpg    - captured scan history and OOD reject demos

Model build history:
  a2a4c9f6134ec0de  round-9 hardened (deployed)
  f48fc157cfe31c5b  round-8 OE (archived in repo as *_round8_prev.tflite)
  a05ded79e3f78895  round-7 OE (archived as *_round7_prev.tflite)

If the camera reports SD FAIL on boot: reformat FAT32, run
releases\REBUILD_SD_CARD.ps1 (or re-extract SD_CARD_KRISHI_DRISHTI_READY.zip
to the card root), reinsert. Never unplug the card mid-write.
